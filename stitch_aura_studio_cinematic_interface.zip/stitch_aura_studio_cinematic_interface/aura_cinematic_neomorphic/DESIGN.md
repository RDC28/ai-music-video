---
name: Aura Cinematic Neomorphic
colors:
  surface: '#10131b'
  surface-dim: '#10131b'
  surface-bright: '#363941'
  surface-container-lowest: '#0b0e15'
  surface-container-low: '#191b23'
  surface-container: '#1d1f27'
  surface-container-high: '#272a32'
  surface-container-highest: '#32353d'
  on-surface: '#e0e2ec'
  on-surface-variant: '#bbc9cd'
  inverse-surface: '#e0e2ec'
  inverse-on-surface: '#2d3038'
  outline: '#869397'
  outline-variant: '#3c494c'
  surface-tint: '#40d8f7'
  primary: '#a4ecff'
  on-primary: '#003640'
  primary-container: '#3dd6f5'
  on-primary-container: '#005a69'
  inverse-primary: '#006879'
  secondary: '#c6bfff'
  on-secondary: '#2800a0'
  secondary-container: '#422bbf'
  on-secondary-container: '#b7afff'
  tertiary: '#ffdbab'
  on-tertiary: '#442b00'
  tertiary-container: '#ffb741'
  on-tertiary-container: '#704a00'
  error: '#F87171'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#aaedff'
  primary-fixed-dim: '#40d8f7'
  on-primary-fixed: '#001f26'
  on-primary-fixed-variant: '#004e5c'
  secondary-fixed: '#e4dfff'
  secondary-fixed-dim: '#c6bfff'
  on-secondary-fixed: '#160066'
  on-secondary-fixed-variant: '#3f28bc'
  tertiary-fixed: '#ffddb1'
  tertiary-fixed-dim: '#ffba4a'
  on-tertiary-fixed: '#291800'
  on-tertiary-fixed-variant: '#624000'
  background: '#10131b'
  on-background: '#e0e2ec'
  surface-variant: '#32353d'
  ink-950: '#090C13'
  ink-900: '#111723'
  ink-800: '#1A2231'
  cyan-500: '#3DD6F5'
  cyan-400: '#74E6FF'
  cyan-300: '#B6F3FF'
  violet-500: '#8071FF'
  violet-400: '#A99FFF'
  success: '#34D399'
  warning: '#FBBF24'
typography:
  display-2xl:
    fontFamily: Space Grotesk
    fontSize: 2.125rem
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-xl:
    fontFamily: Space Grotesk
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 1.125rem
    fontWeight: '500'
    lineHeight: '1.3'
  body-md:
    fontFamily: DM Sans
    fontSize: 0.9375rem
    fontWeight: '400'
    lineHeight: '1.6'
  body-sm:
    fontFamily: DM Sans
    fontSize: 0.8125rem
    fontWeight: '400'
    lineHeight: '1.5'
  label-mono:
    fontFamily: Space Mono
    fontSize: 0.6875rem
    fontWeight: '700'
    lineHeight: '1.4'
    letterSpacing: 0.08em
  headline-2xl-mobile:
    fontFamily: Space Grotesk
    fontSize: 1.75rem
    fontWeight: '700'
    lineHeight: '1.1'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  stage-rail-collapsed: 3.75rem
  stage-rail-expanded: 12.5rem
  top-strip-height: 2.75rem
  gutter: 1.5rem
  panel-gap: 1px
  container-padding: 2rem
---

## Brand & Style
The design system embodies a **Cinematic Editorial High-Craft** aesthetic, tailored for professional creators navigating complex AI generative workflows. The personality is sophisticated, technical, and atmospheric—evoking the feeling of a high-end film production suite.

The visual direction utilizes a **Dark Neomorphic** foundation. Unlike traditional soft neomorphism, this "Cinematic" variation uses deeper tonal ranges, sharper directional light sources, and asymmetrical compositions to create a sense of focused physical depth. It prioritizes information density without sacrificing the "breathability" of high-end editorial layouts. 

The emotional response should be one of **controlled power and creative immersion**—where the interface recedes to let the generative art take center stage, while the controls feel tactile and authoritative.

## Colors
The palette is rooted in the **Ink** family—a series of deep, desaturated navies that provide a high-contrast base for technical work. 

- **Primary (Cyan):** Used for brand presence and primary generative actions. It represents the "energy" of the AI.
- **Secondary (Violet):** Used for secondary creative controls, selection states, and edit-mode accents.
- **Ink Tones:** `--ink-950` serves as the global backdrop; `--ink-900` for primary panels; `--ink-800` for elevated cards and raised surfaces.
- **Semantic Logic:** Cyan is interactive/brand, *not* success. Use Success Green only for confirmed approvals. Use Warning Gold for "Regenerate" actions that might overwrite data. 

All interactive states should maintain a "glow" or "vibrancy" against the dark backgrounds, ensuring high digital legibility.

## Typography
The system employs a strict editorial rhythm using three distinct typefaces:

1.  **Space Grotesk (Headlines):** Used for structural titles and primary navigation. Its geometric character reinforces the technical "AI" nature of the product.
2.  **DM Sans (Body):** Optimized for readability in dense workspace panels. Used for all descriptions, form labels, and instructions.
3.  **Space Mono (Metadata):** Reserved exclusively for "kickers" (small labels above headlines), technical parameters, and code-like data strings. Use uppercase for kickers to establish hierarchy.

**Scale & Rhythm:**
- Use `display-2xl` sparingly for hero sections.
- `label-mono` should always be paired with high letter-spacing (8%) for legibility.
- Maintain a clear vertical rhythm by ensuring all text blocks align to a 4px baseline grid internally.

## Layout & Spacing
The layout follows a **3-Panel Architecture** optimized for widescreen production workflows.

- **Panel 1 (StageRail):** Fixed to the left. It contains the primary navigation steps. It is expanded by default (200px) and collapses to an icon-only rail (60px).
- **Panel 2 (Center Panel):** The fluid workspace. This panel expands to fill available space and houses the primary visual or timeline content.
- **Panel 3 (Right Panel):** The Technical Inspector. It houses fine-tuned controls and generation parameters. It is 320px by default but user-resizable.

**Reflow Rules:**
- **Desktop (>1280px):** Full 3-panel visibility.
- **Tablet (768px - 1280px):** Right Panel becomes an overlay drawer to preserve Center Panel integrity.
- **Mobile (<768px):** StageRail collapses to a bottom bar or hamburger menu; panels stack vertically.
- **Alignment:** The top edge of all panels must align perfectly with the bottom of the Top Strip to maintain a "unified machine" appearance.

## Elevation & Depth
This design system uses **Tonal Neomorphism** to create depth. Surfaces are not just "on top" of each other; they are extruded from the base.

- **Light Source:** Assume a single light source from the top-left (135 degrees).
- **Raised Surfaces (`--neo-raised`):** Use a dual shadow stack: a light highlight (white at 5% opacity) on the top-left edge and a deep shadow (black at 40% opacity) on the bottom-right.
- **Inset Surfaces (`--neo-inset`):** Used for input fields and "sunken" wells. The shadow is internal, creating a "carved" look.
- **Glows (`--neo-active`):** Interactive elements do not just lift; they emit a soft color-tinted glow (using Cyan or Violet) to indicate focus or active status.
- **Dividers:** Use 1px borders in `--ink-800` instead of heavy lines to maintain a "machined" aesthetic.

## Shapes
The shape language is "Soft-Technical." Elements use a **0.5rem (8px)** base radius to feel modern and approachable while maintaining a structured, architectural look.

- **Base Radius (`0.5rem`):** Standard buttons, input fields, and small cards.
- **Large Radius (`1rem`):** Main workspace panels and primary container units.
- **Pill Radius:** Reserved exclusively for status indicators (Chips) and the "Generate" CTA to differentiate them from structural UI.

Avoid 0px (Sharp) edges to prevent the UI from feeling "hostile" or purely "utilitarian."

## Components

### Buttons & Semantic States
- **Generate (Primary):** Solid `--cyan-500` background. High visual weight. On hover, apply a cyan outer glow.
- **Regenerate (Cautionary):** Outlined with `--warning` amber. Used when an action will replace existing work.
- **Approve (Success):** Subtle green tint with `--success` icon. Pinned to the top-right of completed assets.
- **Delete (Destructive):** Low-opacity red text that transitions to solid `--error` red on hover.

### Input Fields
Inputs are **inset** into the UI. Use `--font-body` for text and `--label-mono` for field titles positioned above the input. Focus states must use a 1px `--cyan-500` inner border.

### Chips & Tags
Small, pill-shaped elements with `--ink-800` backgrounds. Use `--label-mono` for the text inside.

### Cards
Cards use the `--neo-flat` style—a subtle 1px border with no heavy shadow until hovered. On hover, the card "lifts" using the `--neo-raised` shadow spec.

### Empty States
The Right Panel should never be empty or cluttered with disabled fields. When no item is selected, display a centered block of `--text-muted` copy with a "Space Mono" kicker (e.g., "INSPECTOR // IDLE").

### Motion & Transitions
- **Reveal:** Panels should slide in from the right using `--ease-premium` (500ms).
- **Hover Transitions:** Instant opacity changes (160ms) for buttons, but slow, cinematic "glow-ups" (300ms) for active cards.
- **No Bounce:** All transitions must be linear-out or cubic-bezier to maintain a professional, high-end feel.